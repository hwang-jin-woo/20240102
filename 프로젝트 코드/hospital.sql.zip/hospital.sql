-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- 생성 시간: 23-12-29 03:54
-- 서버 버전: 10.4.32-MariaDB
-- PHP 버전: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `hospital`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `admin`
--

CREATE TABLE `admin` (
  `admin` int(10) NOT NULL,
  `member` int(9) NOT NULL,
  `hpinformation` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 테이블 구조 `board`
--

CREATE TABLE `board` (
  `uboard` int(15) NOT NULL,
  `title` varchar(255) NOT NULL,
  `context` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  `modiatedDate` datetime NOT NULL,
  `writer` varchar(20) NOT NULL,
  `modifiter` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 테이블의 덤프 데이터 `board`
--

INSERT INTO `board` (`uboard`, `title`, `context`, `time`, `modiatedDate`, `writer`, `modifiter`) VALUES
(1, 'asd', '0', '2023-12-15 00:00:00', '2023-12-18 00:00:00', '3333', '3333'),
(2, '', '0', '2023-12-15 00:00:00', '2023-12-18 00:00:00', '3333', '3333'),
(4, 'hfg', '0', '2023-12-15 00:00:00', '2023-12-18 04:15:03', '1111', '1111'),
(6, 'ㅁ', '0', '2023-12-15 13:15:32', '2023-12-18 04:17:33', '1111', '1111'),
(8, 'ㅣㅣ', '01', '2023-12-15 14:04:05', '2023-12-19 05:28:18', '2222', '2222'),
(9, 'a', '12711', '2023-12-18 09:14:19', '2023-12-28 11:54:07', '1234', '1234'),
(11, 'g', '0', '2023-12-18 11:33:50', '2023-12-18 11:33:50', '1234', '1234'),
(13, 'a', '1', '2023-12-18 11:37:15', '2023-12-18 02:38:04', '1234', '1234'),
(14, '11', '12', '2023-12-18 11:41:32', '2023-12-19 03:36:18', '1234', '1234'),
(20, '11', 'a11', '2023-12-19 14:59:22', '2023-12-19 15:17:44', '1234', '1234'),
(22, '11', '11', '2023-12-21 11:05:36', '2023-12-21 11:05:36', '2222', NULL),
(24, '', '', '2023-12-28 10:36:35', '2023-12-28 10:36:35', '1234', NULL);

-- --------------------------------------------------------

--
-- 테이블 구조 `distancehp`
--

CREATE TABLE `distancehp` (
  `hp` int(15) NOT NULL,
  `hp_name` varchar(20) NOT NULL,
  `distance` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 테이블의 덤프 데이터 `distancehp`
--

INSERT INTO `distancehp` (`hp`, `hp_name`, `distance`) VALUES
(1, '에이스마일치과병원', '701m'),
(2, '사과나무치과의원', '753m'),
(3, '박붕연내과의원', '753m'),
(4, '반석편한신경외과의원', '753m'),
(5, '호랑이한의원', '753m'),
(6, '밝은눈세상의원(안과)', '788m'),
(7, '반석이비인후과의원', '788m'),
(8, '반석내과영상의학과의원', '788m'),
(9, '엠의원(피부과)', '906m'),
(10, '유성선병원(종합)', '3km');

-- --------------------------------------------------------

--
-- 테이블 구조 `favoritehp`
--

CREATE TABLE `favoritehp` (
  `hpfa` int(10) NOT NULL,
  `hp_name` varchar(15) NOT NULL,
  `uid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 테이블의 덤프 데이터 `favoritehp`
--

INSERT INTO `favoritehp` (`hpfa`, `hp_name`, `uid`) VALUES
(1, '유성선병원', '1234'),
(2, '에이스마일치과병원', '1313'),
(3, '엠의원(피부과)', '3333');

-- --------------------------------------------------------

--
-- 테이블 구조 `hpinformation`
--

CREATE TABLE `hpinformation` (
  `hpif` int(15) NOT NULL,
  `hp_name` varchar(15) NOT NULL,
  `hp_location` varchar(50) NOT NULL,
  `hp_time` varchar(255) NOT NULL,
  `hp_phone` varchar(11) NOT NULL,
  `hp_review` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 테이블의 덤프 데이터 `hpinformation`
--

INSERT INTO `hpinformation` (`hpif`, `hp_name`, `hp_location`, `hp_time`, `hp_phone`, `hp_review`) VALUES
(1, '에이스마일치과병원', '대전 유성구 반석로 24 2층 3층', '일\r\n정기휴무 그외 09:30 - 19:00\r\n', '042-826-288', '513'),
(2, '사과나무치과의원', '유성구 반석로 23 제일프라자', '일 정기휴무 \r\n그 외 09:30 - 18:00 \r\n12:30 - 14:00 휴게시간\r\n토\r\n09:30 - 12:00\r\n- 토요일 2. 4주 휴진\r\n ', '042-824-280', '28'),
(3, '반석편한신경외과의원', '유성구 반석로 23 제일프라자 2층 201호, 202호', '일 정기휴무 \r\n그 외 09:00 - 18:00\r\n13:00 - 14:00 휴게시간\r\n토\r\n09:00 - 13:00', '042-721-755', '313'),
(4, '호랑이한의원', '유성구 반석로 28 쎈타프라자1', '일 정기휴무 \r\n그 외 09:00 - 13:30\r\n12:30 - 14:00 휴게시간 \r\n토\r\n09:00 - 13:30\r\n- 일,목요일을 제외한 공휴일은 13:30까지진료', '042-826-002', '85'),
(5, '밝은눈세상의원(안과)', '유성구 반석로 16 반석크리닉빌딩', '일정기휴무 \r\n그 외 09:30 - 18:30\r\n12:30 - 14:00 휴게시간\r\n토\r\n09:30 - 13:30\r\n- 접수마감-오전12:15/오후18:00/토12:30', '042-826-850', '202'),
(6, '반석이비인후과의원', '유성구 반석로 16 반석크리닉빌딩', '일정기휴무 \r\n그 외 09:00 - 18:10\r\n12:30 - 14:00 휴게시간\r\n토\r\n09:00 - 13:00', '042-826-887', '208'),
(7, '반석내과영상의학과의원', '유성구 반석로 16 반석크리닉빌딩', '일 정기휴무 \r\n그 외 09:00 - 18:30\r\n토\r\n09:00 - 12:30\r\n', '042-826-180', '287'),
(8, '엠의원(피부과)', '유성구 반석로 7 애니빌프라자 301호, 302호', '일 정기휴무\r\n그 외 09:30 - 18:30\r\n12:30 - 13:30 휴게시간\r\n토\r\n09:30 - 12:00\r\n정기 휴진일:한달에 2번 둘째 넷째 목요일', '042-825-597', '313'),
(9, '박붕연내과의원', '유성구 반석로 23 제일프라자', '일 정기휴무\r\n그 외 09:00 - 18:00\r\n12:30 - 14:00 휴게시간\r\n토\r\n09:00 - 12:30\r\n', '0507-1373-4', '147'),
(10, '유성선병원(종합)', '유성구 북유성대로 93', '일 정기휴무\r\n그 외 08:30 - 17:30\r\n12:30 - 13:30 휴게시간\r\n토\r\n08:30 - 12:30\r\n', '1588-7011', '633');

-- --------------------------------------------------------

--
-- 테이블 구조 `member`
--

CREATE TABLE `member` (
  `uid` int(9) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `user_pw` varchar(50) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_gender` bit(1) NOT NULL COMMENT '0:남자,1:여자',
  `user_phone` varchar(11) NOT NULL,
  `user_birth` date NOT NULL,
  `user_location` varchar(255) DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `postCode` varchar(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  `detailAddress` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 테이블의 덤프 데이터 `member`
--

INSERT INTO `member` (`uid`, `user_id`, `user_pw`, `user_name`, `user_gender`, `user_phone`, `user_birth`, `user_location`, `is_admin`, `postCode`, `address`, `detailAddress`) VALUES
(1, '1234', '1234', '박길동', b'0', '', '0000-00-00', '0', 0, '', '', ''),
(2, '2222', '2222', '', b'0', '', '0000-00-00', '', 1, '', '', ''),
(3, '1111', '1111', 'aaa', b'0', '', '0000-00-00', '0', 0, '', '', ''),
(4, '3131', '3131', 'ㅁㄴㅇ', b'1', 'ㅇㅁ', '2023-12-14', '대전', 0, '', '', ''),
(5, '5555', '5555', '대전', b'1', '010', '2023-12-01', '대전광역시', 0, '', '', ''),
(6, '1313', '1313', 'ㅁㅁ', b'0', '', '0000-00-00', '', 0, '', '', ''),
(7, '123', '123', '', b'0', '', '0000-00-00', '모름', 0, '', '', ''),
(8, '15', '15', '', b'0', '', '0000-00-00', '', 0, '46031', '부산 기장군 장안읍 판곡길 2', 'ㅁㅁ'),
(9, '19', '11', 'ㄹㄹㄹㄹㄹ', b'1', '', '0000-00-00', '', 0, '35270', '대전 서구 갈마로 3', '');

-- --------------------------------------------------------

--
-- 테이블 구조 `popularhp`
--

CREATE TABLE `popularhp` (
  `hp` int(20) NOT NULL,
  `hp_name` varchar(20) NOT NULL,
  `hp_review` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 테이블의 덤프 데이터 `popularhp`
--

INSERT INTO `popularhp` (`hp`, `hp_name`, `hp_review`) VALUES
(1, '유성선병원(종합)', '633'),
(2, '에이스마일치과병원', '513'),
(3, '엠의원(피부과)', '313'),
(4, '반석편한신경외과의원', '313'),
(5, '반석내과영상의학과의원', '287'),
(6, '반석이비인후과의원', '208'),
(7, '밝은눈세상의원(안과)', '202'),
(8, '박붕연내과의원', '147'),
(9, '호랑이한의원', '85'),
(10, '사과나무치과의원', '28');

-- --------------------------------------------------------

--
-- 테이블 구조 `reservation`
--

CREATE TABLE `reservation` (
  `reservation` int(15) NOT NULL,
  `year` date NOT NULL,
  `hospital` varchar(15) NOT NULL,
  `hospital_name` varchar(20) NOT NULL,
  `user_id` varchar(20) DEFAULT NULL,
  `reservationtime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 테이블의 덤프 데이터 `reservation`
--

INSERT INTO `reservation` (`reservation`, `year`, `hospital`, `hospital_name`, `user_id`, `reservationtime`) VALUES
(1, '2023-12-06', '0', 'hh', '', '2023-12-15 00:00:00'),
(2, '2023-12-19', '0', 'kkkk', NULL, '2023-12-15 00:00:00'),
(3, '0000-00-00', '0', '', NULL, '2023-12-15 00:00:00'),
(4, '2023-12-12', '내과', '호ㅗㅗ', NULL, '2023-12-15 13:24:21'),
(5, '2023-12-06', '외과', 'asdasd', NULL, '2023-12-18 09:01:31'),
(6, '0000-00-00', '내과', '', NULL, '2023-12-18 09:08:25'),
(7, '2023-12-19', '외과', 'dddd', NULL, '2023-12-18 09:09:00'),
(8, '0000-00-00', '', '', NULL, '2023-12-18 13:41:08'),
(9, '0000-00-00', '', 'a', NULL, '2023-12-19 16:10:36');

-- --------------------------------------------------------

--
-- 테이블 구조 `reservationmember`
--

CREATE TABLE `reservationmember` (
  `re_member` int(15) NOT NULL,
  `member` varchar(20) NOT NULL,
  `hospital_name` varchar(20) NOT NULL,
  `reservationtime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 테이블의 덤프 데이터 `reservationmember`
--

INSERT INTO `reservationmember` (`re_member`, `member`, `hospital_name`, `reservationtime`) VALUES
(1, '2명', '박붕연내과의원', '2023-12-18 01:24:44'),
(2, '3명', '반석내과영상의학과의원', '2023-12-18 01:24:44');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin`);

--
-- 테이블의 인덱스 `board`
--
ALTER TABLE `board`
  ADD PRIMARY KEY (`uboard`);

--
-- 테이블의 인덱스 `distancehp`
--
ALTER TABLE `distancehp`
  ADD PRIMARY KEY (`hp`);

--
-- 테이블의 인덱스 `favoritehp`
--
ALTER TABLE `favoritehp`
  ADD PRIMARY KEY (`hpfa`);

--
-- 테이블의 인덱스 `hpinformation`
--
ALTER TABLE `hpinformation`
  ADD PRIMARY KEY (`hpif`);

--
-- 테이블의 인덱스 `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`uid`);

--
-- 테이블의 인덱스 `popularhp`
--
ALTER TABLE `popularhp`
  ADD PRIMARY KEY (`hp`);

--
-- 테이블의 인덱스 `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`reservation`);

--
-- 테이블의 인덱스 `reservationmember`
--
ALTER TABLE `reservationmember`
  ADD PRIMARY KEY (`re_member`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `board`
--
ALTER TABLE `board`
  MODIFY `uboard` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- 테이블의 AUTO_INCREMENT `distancehp`
--
ALTER TABLE `distancehp`
  MODIFY `hp` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- 테이블의 AUTO_INCREMENT `favoritehp`
--
ALTER TABLE `favoritehp`
  MODIFY `hpfa` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 테이블의 AUTO_INCREMENT `hpinformation`
--
ALTER TABLE `hpinformation`
  MODIFY `hpif` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- 테이블의 AUTO_INCREMENT `member`
--
ALTER TABLE `member`
  MODIFY `uid` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 테이블의 AUTO_INCREMENT `popularhp`
--
ALTER TABLE `popularhp`
  MODIFY `hp` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- 테이블의 AUTO_INCREMENT `reservation`
--
ALTER TABLE `reservation`
  MODIFY `reservation` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 테이블의 AUTO_INCREMENT `reservationmember`
--
ALTER TABLE `reservationmember`
  MODIFY `re_member` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
